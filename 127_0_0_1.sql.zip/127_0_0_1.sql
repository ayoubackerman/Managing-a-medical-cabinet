-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 28 déc. 2020 à 21:28
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `admin`
--
CREATE DATABASE IF NOT EXISTS `admin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admin`;

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

CREATE TABLE `consultation` (
  `ID` int(11) NOT NULL,
  `Date_de_consultation` text NOT NULL,
  `Diagnostic` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `consultation`
--

INSERT INTO `consultation` (`ID`, `Date_de_consultation`, `Diagnostic`) VALUES
(1, '01-01-2021', 'angine'),
(2, '01-02-2021', 'angine'),
(3, '02-02-2020', 'covid-19'),
(4, '01-12-2021', 'Cancer'),
(5, '12/12/2000', 'ddvs');

-- --------------------------------------------------------

--
-- Structure de la table `dossier`
--

CREATE TABLE `dossier` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prénom` varchar(20) NOT NULL,
  `Date de naissance` varchar(20) NOT NULL,
  `Genre` varchar(20) NOT NULL,
  `Tel` int(8) NOT NULL,
  `Email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `dossier`
--

INSERT INTO `dossier` (`ID`, `Nom`, `Prénom`, `Date de naissance`, `Genre`, `Tel`, `Email`) VALUES
(1, 'Hamdi', 'Ali', '04/10/2000', 'Homme', 56173226, 'alihamdi572@gmail.com'),
(2, 'Ben Brahim', 'Ayoub', '12/12/2000', 'Homme', 22560031, 'benbrahimayoub@gmail.com'),
(3, 'Hamdi', 'Hatem', '18/09/1994', 'Homme', 26677341, 'hamdii.hatem1@gmail.com'),
(4, 'Ben Nefla', 'Aziz', '04/07/1999', 'Homme', 55984535, 'abennefla@gmail.com'),
(5, 'Kouka', 'Hamza', '15/03/2001', 'Autre', 90774747, 'hamzakouka948@gmail.com'),
(6, 'Chaibi', 'Hager', '12/10/2000', 'Femme', 90123321, 'hager.ch2@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `prescription`
--

CREATE TABLE `prescription` (
  `ID` int(11) NOT NULL,
  `medicament` varchar(40) NOT NULL,
  `analyse` varchar(40) NOT NULL,
  `act_radio` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prescription`
--

INSERT INTO `prescription` (`ID`, `medicament`, `analyse`, `act_radio`) VALUES
(1, 'Grippex', 'oui', 'Radio'),
(2, 'Doliprane', 'oui', 'IRM'),
(3, 'Doliprane', 'oui', 'Scanner'),
(4, 'none', 'oui', 'Scanner '),
(5, 'sdv', 'xdv', 'dxv');

-- --------------------------------------------------------

--
-- Structure de la table `specialiste`
--

CREATE TABLE `specialiste` (
  `ID` int(11) NOT NULL,
  `specialite` varchar(40) NOT NULL,
  `specialiste` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `specialiste`
--

INSERT INTO `specialiste` (`ID`, `specialite`, `specialiste`) VALUES
(1, 'cardiologie', 'Farhani Iheb'),
(2, 'cardiologie', 'Bedhief Jihed'),
(3, 'cardiologie', 'Ben Brahim Moaness'),
(4, 'chirurgie', 'Sassi Malek'),
(5, '12', '12');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD KEY `pk` (`ID`);

--
-- Index pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD KEY `pk_e` (`ID`);

--
-- Index pour la table `specialiste`
--
ALTER TABLE `specialiste`
  ADD KEY `fk` (`ID`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `pk` FOREIGN KEY (`ID`) REFERENCES `dossier` (`ID`);

--
-- Contraintes pour la table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `pk_e` FOREIGN KEY (`ID`) REFERENCES `consultation` (`ID`);

--
-- Contraintes pour la table `specialiste`
--
ALTER TABLE `specialiste`
  ADD CONSTRAINT `fk` FOREIGN KEY (`ID`) REFERENCES `prescription` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
